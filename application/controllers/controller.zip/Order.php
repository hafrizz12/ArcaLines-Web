<?php
class Order extends CI_Controller {
    public function __construct() {
        parent :: __construct();
        $this->load->model('Order_model');
        $this->load->database();
        $this->load->library('session');
    }
    public function index() {
        $data['orders'] = $this->Order_model->get_orders();
        $data['message'] = $this->session->userdata('message');
        $this->load->view('order/index.php', $data);
    }

    public function add_order() {
        $id_user = $this->input->post('id_user');
        $id_menu = $this->input->post('id_menu');
        $statusPayment = $this->input->post('status_payment');
        if (!$id_user || !$id_menu || !$statusPayment) {
            $data['message'] = 'Gagal membuat order';
            $this->session->set_userdata('message', $data['message']);
            $this->session->set_userdata('status', "danger");
            header('Location: '.base_url().'order');
            return;
        }
        $data = array(
            'id_user' => $id_user,
            'id_menu' => $id_menu,
            'status_payment' => $statusPayment
        );
        $orderId = $this->Order_model->create_order($data);
        if ($orderId) {
            require __DIR__ . '/vendor/autoload.php';
	  
            $options = array(
              'cluster' => 'ap1',
              'useTLS' => true
            );
            $pusher = new Pusher\Pusher(
              '2945f9a3ee52c63acff7',
              '90e5dc99c73e72236057',
              '1697462',
              $options
            );
          
            $data['message'] = 'Order has been created with ID of ' . $orderId;
		    $pusher->trigger('HKrestaurant', 'admin', $data['message']);
            $this->session->set_userdata('message', $data['message']);
            header('Location: '.base_url().'order');
        } else {
            echo "Gagal membuat menu";
        }
    }

    public function edit_order($id) {
        $data['order'] = $this->Order_model->get_order($id);
        $this->load->view('order/edit.php', $data);
    }

    public function update_order() {
        $id = $this->input->post('id_order');
        $id_user = $this->input->post('id_user');
        $id_menu = $this->input->post('id_menu');
        $statusPayment = $this->input->post('status_payment');
        $data = array(
            'id_user' => $id_user,
            'id_menu' => $id_menu,
            'status_payment' => $statusPayment
        );
        $orderId = $this->Order_model->update_order($id, $data);
        if ($orderId) {
            require __DIR__ . '/vendor/autoload.php';
	  
            $options = array(
              'cluster' => 'ap1',
              'useTLS' => true
            );
            $pusher = new Pusher\Pusher(
              '2945f9a3ee52c63acff7',
              '90e5dc99c73e72236057',
              '1697462',
              $options
            );
          
            $data['message'] = 'Order with ID of ' . $id . ' has been updated';
		    $pusher->trigger('HKrestaurant', 'admin', $data['message']);
            $this->session->set_userdata('message', $data['message']);
        }
        header('Location: '.base_url().'order');
    }

    public function delete_order($id) {
        $delId = $this->Order_model->delete_order($id);
        require __DIR__ . '/vendor/autoload.php';
	  
        $options = array(
          'cluster' => 'ap1',
          'useTLS' => true
        );
        $pusher = new Pusher\Pusher(
          '2945f9a3ee52c63acff7',
          '90e5dc99c73e72236057',
          '1697462',
            $options
        );
          
        $data['message'] = 'Order with ID of ' . $id . ' has been deleted';
	    $pusher->trigger('HKrestaurant', 'admin', $data['message']);
        $this->session->set_userdata('message', $data['message']);
        header('Location: '.base_url().'order');
        
    }
}
?>