<?php
class Menu extends CI_Controller {
    public function __construct() {
        parent :: __construct();
        $this->load->model('Menu_model');
        $this->load->database();
        $this->load->library('session');
    }
    public function index() {
        $data['menus'] = $this->Menu_model->getMenus();
        $data['message'] = $this->session->userdata('message');
        $data['status'] = $this->session->userdata('status');
        $this->load->view('menu/index.php', $data);
    }

    public function add_menu() {
        $nama = $this->input->post('menu_name');
        $tipe = $this->input->post('type');
        $harga = $this->input->post('price');
        if (!$harga || !$tipe || !$nama) {
            $data['message'] = 'Gagal membuat menu';;
            $this->session->set_userdata('message', $data['message']);
            $this->session->set_userdata('status', "danger");
            header('Location: '.base_url().'menu');
            return;
        }
        $data = array(
            'menu_name' => $nama,
            'type' => $tipe,
            'price' => $harga
        );
        $menu_id = $this->Menu_model->add_menu($data);
        if ($menu_id) {
            require __DIR__ . '/vendor/autoload.php';
	  
            $options = array(
              'cluster' => 'ap1',
              'useTLS' => true
            );
            $pusher = new Pusher\Pusher(
              '2945f9a3ee52c63acff7',
              '90e5dc99c73e72236057',
              '1697462',
              $options
            );

            $data['message'] = 'Menu has been created with ID of ' . $menu_id;
            $pusher->trigger('HKrestaurant', 'admin', $data['message']);
            $this->session->set_userdata('message', $data['message']);
            header('Location: '.base_url().'menu');
        } else {
            $data['message'] = 'Gagal membuat menu';;
            $this->session->set_userdata('message', $data['message']);
            $this->session->set_userdata('status', "danger");
            header('Location: '.base_url().'menu');
            return;
        }
    }

    public function edit_menu($id) {
        $data['menu'] = $this->Menu_model->get_menu($id);
        $this->load->view('menu/edit.php', $data);
    }

    public function update_menu() {
        $id = $this->input->post('id_menu');
        $nama = $this->input->post('menu_name');
        $tipe = $this->input->post('type');
        $harga = $this->input->post('price');
        $data = array(
            'menu_name' => $nama,
            'type' => $tipe,
            'price' => $harga
        );
        $menu_id = $this->Menu_model->update_menu($id, $data);
        if ($menu_id) {
            require __DIR__ . '/vendor/autoload.php';
	  
            $options = array(
              'cluster' => 'ap1',
              'useTLS' => true
            );
            $pusher = new Pusher\Pusher(
              '2945f9a3ee52c63acff7',
              '90e5dc99c73e72236057',
              '1697462',
              $options
            );
          
            $data['message'] = 'Menu with ID of ' . $id . ' has been updated';
		    $pusher->trigger('HKrestaurant', 'admin', $data['message']);
            $this->session->set_userdata('message', $data['message']);
            $this->session->set_userdata('status', "warning");
        }
        header('Location: '.base_url().'menu');
    }

    public function delete_menu($id) {
        $delId = $this->Menu_model->delete_menu($id);
        require __DIR__ . '/vendor/autoload.php';
	  
        $options = array(
          'cluster' => 'ap1',
          'useTLS' => true
        );
        $pusher = new Pusher\Pusher(
          '2945f9a3ee52c63acff7',
          '90e5dc99c73e72236057',
          '1697462',
            $options
        );
          
        $data['message'] = 'Menu with ID of ' . $id . ' has been deleted';
		$pusher->trigger('HKrestaurant', 'admin', $data['message']);
        $this->session->set_userdata('message', $data['message']);
        $this->session->set_userdata('status', "danger");
        header('Location: '.base_url().'menu');
    }
}
?>