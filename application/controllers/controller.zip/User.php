<?php
class User extends CI_Controller {
    public function __construct() {
        parent :: __construct();
        $this->load->model('User_model');
        $this->load->database();
        $this->load->library('session');
    }
    public function index() {
        $data['users'] = $this->User_model->get_users();
        $data['message'] = $this->session->userdata('message');
        $this->load->view('User/index.php', $data);
    }

    public function create_user() {
        $name = $this->input->post('name');
        $password = $this->input->post('password');
        $username = $this->input->post('username');
        $level = $this->input->post('level');
        if (!$name || !$password || !$username || $level) {
            $data['message'] = 'Gagal menambahkan pengguna';;
            $this->session->set_userdata('message', $data['message']);
            $this->session->set_userdata('status', "danger");
            header('Location: '.base_url().'user');
            return;
        }
        $data = array(
            'name' => $name,
            'password' => $password,
            'username' => $username,
            'level' => $level
        );
        $user_id = $this->User_model->create_user($data);
        if ($user_id) {
            require __DIR__ . '/vendor/autoload.php';
	  
            $options = array(
              'cluster' => 'ap1',
              'useTLS' => true
            );
            $pusher = new Pusher\Pusher(
              '2945f9a3ee52c63acff7',
              '90e5dc99c73e72236057',
              '1697462',
              $options
            );
          
            $data['message'] = 'User has been created with ID of ' . $user_id;
		    $pusher->trigger('HKrestaurant', 'admin', $data['message']);
            $this->session->set_userdata('message', $data['message']);
            header('Location: '.base_url().'user');
        } else {
            echo "Gagal membuat user";
        }
    }

    public function edit_user($id) {
        $data['user'] = $this->User_model->get_user($id);
        $this->load->view('User/edit.php', $data);
    }

    public function update_user() {
        $id = $this->input->post('id');
        $name = $this->input->post('name');
        $password = $this->input->post('password');
        $username = $this->input->post('username');
        $level = $this->input->post('level');
        $data = array(
            'name' => $name,
            'password' => $password,
            'username' => $username,
            'level' => $level
        );
        $user_id = $this->User_model->update_user($id, $data);
        if ($user_id) {
            require __DIR__ . '/vendor/autoload.php';
	  
            $options = array(
              'cluster' => 'ap1',
              'useTLS' => true
            );
            $pusher = new Pusher\Pusher(
              '2945f9a3ee52c63acff7',
              '90e5dc99c73e72236057',
              '1697462',
              $options
            );
          
            $data['message'] = 'User with ID of ' . $id . ' has been updated';
		    $pusher->trigger('HKrestaurant', 'admin', $data['message']);
            $this->session->set_userdata('message', $data['message']);
        }
        header('Location: '.base_url().'user');
    }

    public function delete_user($id) {
        $delId = $this->User_model->delete_user($id);
        if ($delId) {
            require __DIR__ . '/vendor/autoload.php';
	  
            $options = array(
              'cluster' => 'ap1',
              'useTLS' => true
            );
            $pusher = new Pusher\Pusher(
              '2945f9a3ee52c63acff7',
              '90e5dc99c73e72236057',
              '1697462',
              $options
            );
          
            $data['message'] = 'User with ID of ' . $id . ' has been deleted';
		    $pusher->trigger('HKrestaurant', 'admin', $data['message']);
            $this->session->set_userdata('message', $data['message']);
            header('Location: '.base_url().'user');
        }
    }
}
?>