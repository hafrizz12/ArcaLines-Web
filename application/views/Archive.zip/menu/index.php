<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menu List</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/sweetalert2@10.10.1/dist/sweetalert2.min.css'>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,400;0,500;1,400&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://ireade.github.io/Toast.js/css/Toast.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</head>
<body>
<style>
    p {
        font-family: 'Poppins';
    }

    @media screen and (max-width: 768px) {
        .mobileAct {
            width: 100%;
            margin-bottom: 0.5rem;
        }
    }
</style>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10.10.1/dist/sweetalert2.all.min.js"></script>
<script src="https://js.pusher.com/8.2.0/pusher.min.js"></script>
<script src="https://eventnimz-jktstrg.is3.cloudhost.id/eventnimz-jktstrg/19/haf-school-stuff/test/Toast.js"></script>
<script>
    var pusher = new Pusher('2945f9a3ee52c63acff7', {
      cluster: 'ap1'
    });
    
    var channel = pusher.subscribe('HKrestaurant');
    channel.bind('admin', function(data) {
    new Toast({message: data, type: 'danger', customButtons: [{text: 'Refresh data', onClick: function() { window.location.reload();}},]});
    });

    function deleteConfirm(x) {
        Swal.fire({
            title: "Are you sure?",
            text: "Deleting data means losing the data, no backsies.",
            icon: "warning",
            showCancelButton: true,
            confirmButtonColor: "#3085d6",
            cancelButtonColor: "#d33",
            confirmButtonText: "Yes, pls delete!"
            }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = "<?php echo base_url('Menu/delete_menu/');?>" + x;
            }
            });
    }
  </script>
  <?php
  if (isset($message)) {
    echo '
    <script>
    new Toast({message: "'. $message .'", type: "'. $status .'"});
    </script>
    ';
    $this->session->unset_userdata('message');
    $this->session->unset_userdata('status');
  }
  ?>
    <nav>
        <style>
            .nav-btn {
                display: inline-block;
                background-color: #4CAF50;
                color: white;
                padding: 10px 20px;
                text-align: center;
                text-decoration: none;
                font-size: 16px;
                margin: 4px 2px;
                cursor: pointer;
                border-radius: 5px;
            }
        </style>
        <div class="container" style="margin-top: 1rem;">
        <div style="text-align: center;">
        <h1><b>HKRestaurant</b></h1>
        <nav>
            <a href="/user" class="nav-btn">User</a>
            <a href="/menu" class="nav-btn">Menu</a>
            <a href="/order" class="nav-btn">Order</a>
        </nav>
    </div>
    <h2 style="font-family: poppins; margin-top: 1rem;">Add Menu</h2>
    <p>Kamu bisa menambahkan menu dengan mengisi formulir dibawah</p>
    <hr style="width: 10%; border: 0.3rem solid black; border-radius: 15rem;">
    <div class="container row">
    <div class="col-md-6 col-12">
    <div class="row">
    <form action="<?php echo base_url('Menu/add_menu'); ?>" method="POST" class="form-control">
    <div class="col-12">
    <label for="menu_name">Menu Name</label>
    <input type="text" name="menu_name" id="menu_name" placeholder="Menu Name" class="form-control" style="width: 100%;">
          </div>
    <div class="col-12">
    <label for="type">Type</label>
    <select  name="type" id="type" class="form-control" style="width: 100%" name="level" id="level">
        <option value="Makanan">Makanan</option>
        <option value="Minuman">Minuman</option>
    </select>
          </div>
    <div class="col-12">
    <label for="price">Price</label>
    <input type="text" name="price" id="price" placeholder="Price" class="form-control" style="width: 100%;">
          </div>
    <div class="col-12">
    <input type="submit" class="btn btn-primary" style="margin-top: 1rem;" value="Submit">
          </div>
    </form>
    </div>
    </div>
    </div>
    <h1 style="margin-top: 1rem;">Menu List</h1>
    <div style="overflow-x: scroll">
    <table border=1 class="table table-bordered table-striped" style="width: 100%">
        <tr>
            <th>ID Menu</th>
            <th>Nama Menu</th>
            <th>Tipe</th>
            <th>Harga</th>
            <th>Action</th>
        </tr>
        <?php foreach($menus as $menu) { ?>
            <tr>
                <td><?php echo $menu->id_menu; ?></td>
                <td><?php echo $menu->menu_name; ?></td>
                <td><?php echo $menu->type; ?></td>
                <td><?php echo 'IDR ' . number_format($menu->price, 0, ',', '.'); ?></td>
                <td>
                    <a class="btn mobileAct btn-warning" href="<?php echo base_url('Menu/edit_menu/'.$menu->id_menu); ?>">Edit</a>
                    <a class="btn mobileAct btn-danger" onclick="deleteConfirm(<?php echo $menu->id_menu; ?>)">Delete</a>
                </td>
            </tr>
        <?php } ?>
    </table>
        </div>
    </div>
</body>
</html>