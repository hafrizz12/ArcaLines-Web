<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit User</title>
    <link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/sweetalert2@10.10.1/dist/sweetalert2.min.css'>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</head>
<body>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10.10.1/dist/sweetalert2.all.min.js"></script>
<nav>
        <style>
            .nav-btn {
                display: inline-block;
                background-color: #4CAF50;
                color: white;
                padding: 10px 20px;
                text-align: center;
                text-decoration: none;
                font-size: 16px;
                margin: 4px 2px;
                cursor: pointer;
                border-radius: 5px;
            }
        </style>
        <script>
            function editConfirm(event) {
                event.preventDefault();
                Swal.fire({
                    title: "Are you sure?",
                    text: "This will change the data value, such actions won't be recovered that easy.",
                    icon: "warning",
                    showCancelButton: true,
                    confirmButtonColor: "#3085d6",
                    cancelButtonColor: "#d33",
                    confirmButtonText: "Yes, i consent to edit!"
                }).then((result) => {
                    if (result.isConfirmed) {
                        event.target.form.submit();
                    }
                });
            }
        </script>
        <div class="container" style="margin-top: 1rem;">
        <nav>
        <a href="/order" class="nav-btn">Kembali</a>
        </nav>
    <h1 style="margin-top: 1rem;">Edit User</h1>
    <form action="<?php echo base_url('User/update_user'); ?>" method="POST" class="form-control">
        <input type="hidden" name="id" value="<?php echo $user->id; ?>">
        <label for="name">Name</label>
        <input type="text" name="name" id="name" placeholder="Name" class="form-control" style="width: 100%;" value="<?php echo $user->name; ?>">
        <br>
        <label for="username">Username</label>
        <input type="text" name="username" id="username" placeholder="Username" class="form-control" style="width: 100%;" value="<?php echo $user->username; ?>">
        <br>
        <label for="password">Password</label>
        <input type="password" name="password" id="password" placeholder="Password" class="form-control" style="width: 100%;" value="<?php echo $user->password; ?>">
        <br>
        <label for="level">Level</label>
        <select style="width: 100%" class="form-control" name="level" id="level">
            <option value="0" <?php if($user->level == 0) echo 'selected'; ?>>User</option>
            <option value="1" <?php if($user->level == 1) echo 'selected'; ?>>Admin</option>
        </select>
        <br>
        <input class="btn btn-primary" onclick="editConfirm(event)" value="Submit">
    </form>
    </body>
 </html>